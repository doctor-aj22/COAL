.model small
.data

num1 db 3
num2 db 2

str1 db 10,13,"Addition is: $"
str2 db 10,13,"Subtraction is: $"

.code

mov ax, @data
mov ds, ax                        

mov al, num1
add al, num2
mov bl, al        ;
                          
lea dx, str1
mov ah, 09h
int 21h                  

add bl, 48
mov dl, bl
mov ah, 02h
int 21h

mov al, num1
sub al, num2
mov bl, al        

lea dx, str2
mov ah, 09h
int 21h

add bl, 48
mov dl, bl
mov ah, 02h
int 21h

mov ah, 4ch
int 21h

end
