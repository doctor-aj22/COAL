.model small
.data
    a db "Dividend: $" 
    b db 0ah,0dh,"Divisor: $"
    q db 0ah,0dh,"Quotient: $"
    r db 0ah,0dh,"Remainder: $"

.code
    mov ax, @data
    mov ds, ax

    lea dx, a
    mov ah, 09h
    int 21h

    mov ah, 01h
    int 21h
    sub al, 48
    mov ah, 0
    mov bx, ax

    lea dx, b
    mov ah, 09h
    int 21h

    mov ah, 01h
    int 21h
    sub al, 48
    mov cl, al

    mov ax, bx
    div cl

    mov bx, ax

    lea dx, q
    mov ah, 09h
    int 21h

    mov dl, bl
    add dl, 48
    mov ah, 02h
    int 21h

    lea dx,r
    mov ah, 09h
    int 21h

    mov dl, bh
    add dl, 48
    mov ah, 02h
    int 21h