.model small
.data
    a db "First number: $" 
    b db 10,13,"Second number: $"
    c db 10,13,"Multiplication: $"

.code
    mov ax, @data
    mov ds, ax

    lea dx, a
    mov ah, 09h
    int 21h

    mov ah, 01h
    int 21h
    sub al, 48
    mov bl, al

    lea dx, b
    mov ah, 09h
    int 21h

    mov ah, 01h
    int 21h
    sub al, 48

    mul bl
    
    mov bl, al
    add bl, 48

    lea dx, c
    mov ah, 09h
    int 21h

    mov dl, bl
    mov ah, 02h
    int 21h