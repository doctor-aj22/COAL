.MODEL SMALL

.DATA
    a dw 245
    b db "Number: $"

.CODE

    mov ax,@DATA
    mov ds,as

    lea dx,a
    mov ah,09h
    int 21h

    
                                      
   