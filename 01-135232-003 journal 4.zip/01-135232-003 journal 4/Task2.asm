.model small

.data 

    num1 db -8
    num2 db  3
    num3 db  2


.code
main:

 
mov ax,@data     
mov ds,ax  




mov al,num1
mov bl,num2
imul bl

mov cl,num3
idiv cl



       
mov ah,4ch
int 21h

end main