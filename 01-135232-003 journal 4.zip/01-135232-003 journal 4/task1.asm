.model small

.data 

    num1 db -8
    num2 db -3
    


.code
main:

 
mov ax,@data     
mov ds,ax  

;dividing negative with negative number

mov al,num1 
mov ah,00h
cbw
mov bl,num2
idiv bl
       
       
mov ah,4ch
int 21h

end main