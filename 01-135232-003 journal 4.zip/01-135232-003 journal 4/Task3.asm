.model small


.data

.code
main:

mov ax, @data
mov ds, ax


mov ah, 01h
int 21h   

sub al, 30h
mov ah, 00h
mov bl, 100
mul bl
mov cx, ax


mov ah, 01h
int 21h     

sub al, 30h
mov ah, 00h  

mov bl, 10
mul bl
add cx, ax


mov ah, 01h
int 21h      

sub al, 30h
mov ah, 00h
add cx, ax

mov ah, 4Ch
int 21h

end main