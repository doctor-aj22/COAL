.model small 
org 100h
.data
    
.code 
    mov cx, 9
    mov bl, 9
L1:
    mov al, bl
    mov ah, 0
    mov bh, 2
    div bh
    cmp ah,1
    jne a
        mov dl,bl
        add dl, '0'
        mov ah,2
        int 21h
    a:
        dec bl
        loop L1
        mov ah,4ch
        int 21h
