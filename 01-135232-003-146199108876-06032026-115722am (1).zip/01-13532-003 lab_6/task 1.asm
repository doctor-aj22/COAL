.model small
.data

.code
main: 

mov dl,'Z'      
mov cx,26       

L1:
mov ah,02h
int 21h        

dec dl          
loop L1

mov ah,4ch
int 21h


end main