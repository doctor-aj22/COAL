.model small 
org 100h
.data  

msg db "Enter 10 numbers: $" 
msg1 db 10,13, "This is Highest Number: $"
    
.code 
main:
    lea dx, msg
    mov ah,09h
    int 21h
    
    
    mov cx,10
    mov ah,01h
    int 21h
    sub al,30h
    mov bl,al      
    
    dec cx

L1:
   
    mov ah,01h
    int 21h
    sub al,30h
    
    cmp al,bl
    jle Aj
    mov bl,al

Aj:
loop L1


    mov dl,10
    mov ah,02h
    int 21h
    
    mov dl,13
    mov ah,02h
    int 21h
    
    lea dx,msg1
    mov ah,09h
    int 21h
    
    mov dl,bl
    add dl,30h
    mov ah,02h
    int 21h
    
    mov ah,4ch
    int 21h