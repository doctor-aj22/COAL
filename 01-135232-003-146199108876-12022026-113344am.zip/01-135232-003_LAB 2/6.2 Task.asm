.model small
.data

dr db "    *",10,13,
   db "  *****",10,13,
   db " *******",10,13,
   db "  *****",10,13,
   db "    *",10,13,"$"


.code
mov ax, @data
mov ds, ax

mov dx, offset dr
mov ah, 09h
int 21h

mov ah, 4ch 
int 21h

