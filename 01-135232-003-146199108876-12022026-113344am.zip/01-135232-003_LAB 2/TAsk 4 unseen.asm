.model small
.data 
msg1 db "Enter first num","$" 
msg2 db "Enter Second num","$"
msg3 db "Sum ","$"  
num1 db ?
num2 db ?
res db ?

 

next db 13,10,"$" 


.code

    mov ax, @data
    mov ds, ax
    
    mov dx, offset msg1
    mov ah,9
    int 21h
    mov ah, 01h       
    int 21h
    sub al, '0'       
    mov num1, al   
      mov dx, offset next
    mov ah,9
    int 21h 
      mov dx, offset msg2
    mov ah,9
    int 21h  
                 
                 
             
    mov ah, 01h       
    int 21h
    sub al, '0'       
    mov num2, al    
     mov dx, offset next
    mov ah,9
    int 21h 
    
    mov al, num1
    add al, num2
    mov res, al  
    
         mov dx, offset msg3
    mov ah,9
    int 21h 
    
    add res, '0'   
    mov dl, res
    mov ah, 02h         
    int 21h

          

    
    mov ah, 4Ch
    int 21h
