.model small
.data
msg1  db "2 * 1 = ","$"
res1  db 2

msg2  db 13,10,"2 * 2 = ","$"
res2  db 4

msg3  db 13,10,"2 * 3 = ","$"
res3  db 6

msg4  db 13,10,"2 * 4 = ","$"
res4  db 8

msg5  db 13,10,"2 * 5 = ","$"
res5  db 10

msg6  db 13,10,"2 * 6 = ","$"
res6  db 12

msg7  db 13,10,"2 * 7 = ","$"
res7  db 14

msg8  db 13,10,"2 * 8 = ","$"
res8  db 16

msg9  db 13,10,"2 * 9 = ","$"
res9  db 18

msg10 db 13,10,"2 * 10 = ","$"
res10 db 20

.code
mov ax,@data
mov ds,ax

; -------- 1 --------
mov dx,offset msg1
mov ah,09h
int 21h
mov dl,res1
add dl,48
mov ah,02h
int 21h

;----------2 --------
mov dx,offset msg2
mov ah,09h
int 21h
mov dl,res2
add dl,48
mov ah,02h
int 21h

;----------3 --------
mov dx,offset msg3
mov ah,09h
int 21h
mov dl,res3
add dl,48
mov ah,02h
int 21h

;----------4---------
mov dx,offset msg4
mov ah,09h
int 21h
mov dl,res4
add dl,48
mov ah,02h
int 21h
;----------5--------- 
mov dx,offset msg5
mov ah,09h
int 21h
mov dl,'1'
mov ah,02h
int 21h
mov dl,'0'
int 21h 
;----------6 --------- 
mov dx,offset msg6
mov ah,09h
int 21h
mov dl,'1'
mov ah,02h
int 21h
mov dl,'2'
int 21h
;----------7--------- 
mov dx,offset msg7
mov ah,09h
int 21h
mov dl,'1'
mov ah,02h
int 21h
mov dl,'4'
int 21h
;----------8 --------- 
mov dx,offset msg5
mov ah,09h
int 21h
mov dl,'1'
mov ah,02h
int 21h
mov dl,'6'
int 21h
;----------9--------- 
mov dx,offset msg9
mov ah,09h
int 21h
mov dl,'1'
mov ah,02h
int 21h
mov dl,'8'
int 21h
;----------10--------- 
mov dx,offset msg10
mov ah,09h
int 21h
mov dl,'2'
mov ah,02h
int 21h
mov dl,'0'
int 21h

mov ah,4Ch
int 21h
