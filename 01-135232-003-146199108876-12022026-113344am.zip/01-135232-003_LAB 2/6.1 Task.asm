.model small
.data

.code
mov ax, @data
mov ds, ax

; -------- Part 1 --------
  
    
mov ah, 02h      
mov dl, 'A'    
int 21h
    
;--------- Part2 ---------

mov ah, 01h
int 21h

 
mov dl, al
mov ah, 02h
int 21h

mov ah, 4ch
int 21h