.model small
org 100h 
.data

msg db "Enter a Grade : $"
msg_a db 10,13, "Grade is :A$"   
msg_b db 10,13, "Grade is :B$"
msg_c db 10,13, "Grade is :C$"
msg_d db 10,13, "Grade is :F$"  
msginvalid db 10,13, "invalid $"  

grade       db ?

.code
mov dx, offset msg
mov ah, 09h
int 21h


mov ah, 01h
int 21h
sub al, '0'
mov bl, al

mov ah, 01h
int 21h
sub al, '0'
mov bh, al

mov al, bl
mov cl, 10
mul cl
add al, bh
mov grade,al

cmp al, 100
ja invalid

cmp al, 90
jae A  

cmp al, 80
jae B

cmp al, 50
jae C

mov dx, offset msg_d 
jmp print

A:
mov dx, offset msg_a
jmp print

B:
mov dx, offset msg_b
jmp print

C:
mov dx, offset msg_c
jmp print

invalid:
mov dx, offset msginvalid

print:

mov ah, 09h
int 21h

mov ah, 4ch
int 21h