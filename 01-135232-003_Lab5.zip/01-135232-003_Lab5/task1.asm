.model small  
org 100h
.data
msg_ent db "Enter one number:","$"
msg_even db 10,13, "Its even number:","$"
msg_odd db 10,13, "its odd number:","$"

.code
main:
mov ax, @data
mov ds, ax

mov dx, offset msg_ent
mov ah, 09h
int 21h

mov ah, 01h
int 21h

sub al, '0'

mov ah, 0
mov bl, 2
div bl

cmp ah, 0
je even

mov dx, offset msg_odd
jmp print_result


even:
mov dx, offset msg_even

print_result:
mov ah, 09h
int 21h

mov ah, 4ch
int 21h   

end                               