
.model tiny            
.CODE
ORG 100h              

main:
    MOV CX, 4          
    MOV BX, 1          

row_loop:
    PUSH CX            
    MOV CX, 4
    SUB CX, BX         
    JZ spaces_done
space_prn:
    MOV DL, ' '
    MOV AH, 02h        
    INT 21h
    LOOP space_prn
spaces_done:

    
    MOV CX, BX         
decr_prn:
    MOV DL, CL         
    ADD DL, '0'        
    INT 21h
    LOOP decr_prn

    
    MOV CX, BX
    DEC CX             
    JZ incr_done       
    MOV DL, '2'        
incr_prn:
    INT 21h           
    INC DL             
    LOOP incr_prn
incr_done:                                      


    MOV DL, 0Dh
    INT 21h
    MOV DL, 0Ah
    INT 21h

   
    INC BX
    POP CX             
    LOOP row_loop

  
    INT 20h

END main