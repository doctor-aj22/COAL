org 100h

mov bl, 5         

outer:
    
    mov al, 5
    sub al, bl      
    mov cl, al

spaces:
    cmp cl, 0
    je numbers
    mov dl, ' '
    mov ah, 02h
    int 21h
    dec cl
    jmp spaces

    
numbers:
    mov cl, bl
    shl cl, 1
    dec cl          

print_row:
    mov dl, bl
    add dl, '0'
    mov ah, 02h
    int 21h
    loop print_row

   
    mov dl, 0Dh
    mov ah, 02h
    int 21h
    mov dl, 0Ah
    int 21h

    dec bl
    cmp bl, 0
    jne outer

; exit properly
mov ah, 4Ch
int 21h